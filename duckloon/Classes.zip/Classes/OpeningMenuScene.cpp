#include "OpeningMenuScene.h"
#include "LevelDemoScene.h"
#include "OptionMenuScene.h"
#include "OpeningStoryScene.h"

#include <iostream>
#include <fstream>
#include <vector>

USING_NS_CC;

//4D974-9QX42-9Y43G-YJ7JG-JDYBP

Scene* OpeningMenu::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	OpeningMenu* layer = OpeningMenu::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

//https://github.com/miloyip/rapidjson
bool OpeningMenu::LoadJSONFileLevel(std::string fileName, rapidjson::Document &document)
{
	std::ifstream file;
	file.open(fileName, std::ifstream::binary);	//open the input file

	if (!file.is_open()){						//file not found
		cocos2d::log("Error: JSON File not found");
		return false;
	}
	std::stringstream strStream;
	strStream << file.rdbuf();						//read the file
	std::string jsonStr = strStream.str();			//str holds the content of the file

	if (document.Parse(jsonStr.c_str()).HasParseError()){	// Parse JSON string into DOM.
		cocos2d::log("Error: JSON File could not be parsed into document");
		return false;
	}
	return true;
}

// on "init" you need to initialize your instance
bool OpeningMenu::init()
{

	//////////////////////////////
	// 1. Initialize
	if (!Layer::init())
	{
		//glClearColor(0.0, 0.0, 0.0, 1.0);
		return false;
	}

	//grabs size of the screen which is used for positioning the background, menu, player, etc.
	Size visibleSize = Director::getInstance()->getVisibleSize(); //width=960 height=640
	Vec2 origin = Director::getInstance()->getVisibleOrigin();  //origin is x=0 y=0

	/////////////////////////////
	// 2. renders background images
	//auto background = Sprite::create(backgroundPic);
	//background->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y)); //center of screen
	//this->addChild(background, -1);

	

	/////////////////////////////
	// 4. Additional Labels
	// add a label shows "Level Demo"
	auto headerLabel = Label::createWithTTF("Main Menu", "fonts/Marker Felt.ttf", 24);
	headerLabel->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 4) * 3)); //top center of the screen
	this->addChild(headerLabel, 1);

	/////////////////////////////
	// 5. add a menu item with "X" image, which is clicked to quit the program.  it's an autorelease object
	auto menu_item_2 = MenuItemFont::create("Options", CC_CALLBACK_1(OpeningMenu::Options, this));
	auto menu_item_3 = MenuItemFont::create("Exit", CC_CALLBACK_1(OpeningMenu::menuCloseCallback, this));

	menu_item_2->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 4) * 2));
	menu_item_3->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 4) * 1));
	auto *menu = Menu::create(menu_item_2, menu_item_3, NULL);
	menu->setPosition(Point(0, 0));
	this->addChild(menu);


	


	this->scheduleUpdate();

	//this->getChildByName("Player");

	return true;
}

void OpeningMenu::NewGame(cocos2d::Ref *pSender) {
	CCLOG("New Game");
	auto scene = OpeningStory::createScene();
	Director::getInstance()->pushScene(scene);
}

void OpeningMenu::Options(cocos2d::Ref *pSender) {
	CCLOG("Options");
	auto scene = OptionMenu::createScene();
	Director::getInstance()->pushScene(scene);
}

bool OpeningMenu::isKeyPressed(EventKeyboard::KeyCode code) {
	// Check if the key is currently pressed by seeing if it's in the std::map keys
	if (keys.find(code) != keys.end())
		return true;
	return false;
}

void OpeningMenu::update(float delta) {
	
}

// Because cocos2d-x requres createScene to be static, we need to make other non-pointer members static
std::map<cocos2d::EventKeyboard::KeyCode,
	std::chrono::high_resolution_clock::time_point> OpeningMenu::keys;

//handles closing the program
void OpeningMenu::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.", "Alert");
	return;
#endif

	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}
