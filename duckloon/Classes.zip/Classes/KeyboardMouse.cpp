
#include "cocos2d.h"

USING_NS_CC;

void CreateMouseListener(EventListenerMouse &mouseListener)
{
	mouseListener.onMouseDown = [](cocos2d::Event* event){

		try {
			EventMouse* mouseEvent = dynamic_cast<EventMouse*>(event);
			mouseEvent->getMouseButton();
			std::stringstream message;
			message << "Mouse event: Button: " << mouseEvent->getMouseButton() << "pressed at point (" <<
				mouseEvent->getLocation().x << "," << mouseEvent->getLocation().y << ")";
			MessageBox(message.str().c_str(), "Mouse Event Details");

		}
		catch (std::bad_cast& e){
			// Not sure what kind of event you passed us cocos, but it was the wrong one
			return;
		}
	};

	mouseListener.onMouseMove = [](cocos2d::Event* event){
		// Cast Event to EventMouse for position details like above
		cocos2d::log("Mouse moved event");
	};

	mouseListener.onMouseScroll = [](cocos2d::Event* event){
		cocos2d::log("Mouse wheel scrolled");
	};

	mouseListener.onMouseUp = [](cocos2d::Event* event){
		cocos2d::log("Mouse button released");
	};
	return;
}