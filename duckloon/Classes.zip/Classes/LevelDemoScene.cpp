#include "LevelDemoScene.h"

#include <iostream>
#include <fstream>
#include <vector>

USING_NS_CC;

//4D974-9QX42-9Y43G-YJ7JG-JDYBP

Scene* LevelDemo::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
	LevelDemo* layer = LevelDemo::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool LevelDemo::LoadJSONFileLevel(std::string fileName, rapidjson::Document &document)
{
	std::ifstream file;
	file.open(fileName, std::ifstream::binary);	//open the input file

	if (!file.is_open()){						//file not found
		cocos2d::log("Error: JSON File not found");
		return false;
	}
	std::stringstream strStream;
	strStream << file.rdbuf();						//read the file
	std::string jsonStr = strStream.str();			//str holds the content of the file

	if (document.Parse(jsonStr.c_str()).HasParseError()){	// Parse JSON string into DOM.
		cocos2d::log("Error: JSON File could not be parsed into document");
		return false;
	}
	return true;
}

// on "init" you need to initialize your instance
bool LevelDemo::init()
{
	// 1. Read and Parse JSON file into DOM.
	rapidjson::Document document;
	if (!LoadJSONFileLevel("json/test.json", document))
		return false;

	assert(document.IsObject());

	assert(document.HasMember("levelName"));
	assert(document["levelName"].IsString());
	std::string levelName;
	levelName = document["levelName"].GetString();

	assert(document.HasMember("playerPic"));
	assert(document["playerPic"].IsString());
	std::string playerPic;
	playerPic = document["playerPic"].GetString();

	assert(document.HasMember("backgroundPic"));
	assert(document["backgroundPic"].IsString());
	std::string backgroundPic;
	backgroundPic = document["backgroundPic"].GetString();
	std::vector<std::string> vec_enemyPics;
	std::vector<double> vec_enemyPosX;
	{
		const rapidjson::Value& a = document["enemies"]; // Using a reference for consecutive access is handy and faster.
		assert(a.IsArray());
		for (rapidjson::SizeType i = 0; i < a.Size(); i++) // rapidjson uses SizeType instead of size_t.
		{
			assert(a[i].HasMember("enemyPic"));
			std::string enemyPic;
			enemyPic = a[i]["enemyPic"].GetString();
			vec_enemyPics.push_back(enemyPic);

			double enemyPosX;
			assert(a[i].HasMember("PositionX"));
			assert(a[i]["PositionX"].IsDouble());
			enemyPosX = a[i]["PositionX"].GetDouble();
			vec_enemyPosX.push_back(enemyPosX);
		}
	}


	// 3. Stringify the DOM
	rapidjson::StringBuffer buffer2;
	rapidjson::Writer<rapidjson::StringBuffer> writer(buffer2);
	document.Accept(writer);


    //////////////////////////////
    // 1. Initialize
	if (!Layer::init())
	{
		//glClearColor(0.0, 0.0, 0.0, 1.0);
		return false;
	}

	//grabs size of the screen which is used for positioning the background, menu, player, etc.
    Size visibleSize = Director::getInstance()->getVisibleSize(); //width=960 height=640
    Vec2 origin = Director::getInstance()->getVisibleOrigin();  //origin is x=0 y=0

	/////////////////////////////
	// 2. renders background images
	auto background = Sprite::create(backgroundPic);
	background->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y)); //center of screen
	this->addChild(background, -1);

	/////////////////////////////
	// 3. Create player and interactive sprites
	_player = Sprite::create(playerPic);
	_player->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y)); //center of screen
	_player->setName("Player"); //used for future references to this sprite
	this->addChild(_player); //sprite added to layer 0


	for (int i = 0; i < vec_enemyPics.size(); i++)
	{
		auto enemySprite = Sprite::create(vec_enemyPics[i]);
		enemySprite->setPosition(Vec2(visibleSize.width * vec_enemyPosX[i] + origin.x, visibleSize.height / 2 + origin.y)); //center of screen
		this->addChild(enemySprite); //sprite added to layer 0
	}

	/////////////////////////////
	// 4. Additional Labels
	// add a label shows "Level Demo"
	auto headerLabel = Label::createWithTTF(levelName, "fonts/Marker Felt.ttf", 24);
	headerLabel->setPosition(Vec2(origin.x + visibleSize.width / 2,
		origin.y + visibleSize.height - headerLabel->getContentSize().height)); //top center of the screen
	this->addChild(headerLabel, 1);

    /////////////////////////////
    // 5. add a menu item with "X" image, which is clicked to quit the program.  it's an autorelease object
    auto closeItem = MenuItemImage::create("pics/menu/CloseNormal.png",
                                           "pics/menu/CloseSelected.png",
										   CC_CALLBACK_1(LevelDemo::menuCloseCallback, this));
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2)); 

    auto menu = Menu::create(closeItem, NULL); // create menu
    menu->setPosition(Vec2::ZERO); //bottom right of the screen
    this->addChild(menu, 2);
	


	auto mouseListener = EventListenerMouse::create();

	mouseListener->onMouseDown = [](cocos2d::Event* event){

		try {
			EventMouse* mouseEvent = dynamic_cast<EventMouse*>(event);
			mouseEvent->getMouseButton();
			std::stringstream message;
			message << "Mouse event: Button: " << mouseEvent->getMouseButton() << "pressed at point (" <<
				mouseEvent->getLocation().x << "," << mouseEvent->getLocation().y << ")";
			MessageBox(message.str().c_str(), "Mouse Event Details");

		}
		catch (std::bad_cast& e){
			// Not sure what kind of event you passed us cocos, but it was the wrong one
			return;
		}
	};

	mouseListener->onMouseMove = [](cocos2d::Event* event){
		// Cast Event to EventMouse for position details like above
		cocos2d::log("Mouse moved event");
	};

	mouseListener->onMouseScroll = [](cocos2d::Event* event){
		cocos2d::log("Mouse wheel scrolled");
	};

	mouseListener->onMouseUp = [](cocos2d::Event* event){
		cocos2d::log("Mouse button released");
	};

	this->_eventDispatcher->addEventListenerWithSceneGraphPriority(mouseListener, this);

    
    //Keyboard event handling based on http://www.gamefromscratch.com/post/2014/10/07/Cocos2d-x-Tutorial-Series-Handling-the-Keyboard.aspx 

	auto keyboardListener = EventListenerKeyboard::create();
	Director::getInstance()->getOpenGLView()->setIMEKeyboardState(true);
	keyboardListener->onKeyPressed = [](EventKeyboard::KeyCode keyCode, Event* event){
		// If a key already exists, do nothing as it will already have a time stamp
		// Otherwise, set's the timestamp to now
		if (keys.find(keyCode) == keys.end()){
			keys[keyCode] = std::chrono::high_resolution_clock::now();
		}
	};
	keyboardListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event){
		//remove the key
		keys.erase(keyCode);
	};

	this->_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardListener, this);
	this->scheduleUpdate();

	//this->getChildByName("Player");

    return true;
}


bool LevelDemo::isKeyPressed(EventKeyboard::KeyCode code) {
	// Check if the key is currently pressed by seeing if it's in the std::map keys
	if (keys.find(code) != keys.end())
		return true;
	return false;
}

void LevelDemo::update(float delta) {
	// Register an update function that checks to see if specific keys are pressed
	// and if it is displays how long, otherwise tell the user to press it
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Node::update(delta);
	if (isKeyPressed(EventKeyboard::KeyCode::KEY_LEFT_ARROW) || isKeyPressed(EventKeyboard::KeyCode::KEY_A)) { //move left
		float posX = _player->getPositionX();
		_player->setPositionX(posX - (visibleSize.width / 8 * delta));
	}
	if (isKeyPressed(EventKeyboard::KeyCode::KEY_RIGHT_ARROW) || isKeyPressed(EventKeyboard::KeyCode::KEY_D)) { //move right
		float posX = _player->getPositionX();
		_player->setPositionX(posX + (visibleSize.width / 8 * delta));
	}
}

// Because cocos2d-x requres createScene to be static, we need to make other non-pointer members static
std::map<cocos2d::EventKeyboard::KeyCode,
	std::chrono::high_resolution_clock::time_point> LevelDemo::keys;

//handles closing the program
void LevelDemo::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
